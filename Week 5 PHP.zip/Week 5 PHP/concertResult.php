<?php 

$seatsPrice = array(
    'A1' => 5000, 'A2' => 3000, 'A3' => 1000,'B1' => 5000,'B2' => 3000, 'B3' => 1000,'C1' => 2000,'C2' => 2000, 'C3' => 2000
);

$totalPrice = 0;
$noSeat = 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style> body,html { height:100%; } </style>
</head>
<body>

    <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="jumbotron-fluid text-center">
                <h1 class="display-4">Ticket Invoice</h1>
                <hr class="lead">
                <p>
                <?php
                    foreach($seatsPrice as $seat => $price) {
    
                        if (isset($_POST[$seat])){

                            if ($seat === 'A1') {

                               $luckyPrice = $price/2;

                                echo $seat.": ".$luckyPrice." THB <span class='text-info font-italic'>[50% of for this particular seat. You lucky!]</span><br>";
                                $totalPrice += $luckyPrice;

                            } else {
                                echo $seat.": ".$price." THB<br>";
                                $totalPrice += $price;
                            }

                            $noSeat++;
                        }
                       
                    }

                    if ($noSeat === 0) {
                        echo "<span style='color:#e01616;'>Please select ticket</span>";
                        echo "<script type='text/javascript'>alert('Please select ticket'); window.location.href='concert.php';</script>";
                    
                    } elseif ($noSeat > 4) {
                        echo "<script type='text/javascript'>alert('Maximum of 4 Seats ONLY!'); window.location.href='concert.php';</script>";
                    
                    } else {
                        echo "<br>Number of seats: <span class='font-weight-itlaic'>".$noSeat."</span><br>Total Price: <span class='font-weight-bold'>".$totalPrice." THB</span>";
                    }
                ?>
                </p>
                <p class="lead">
                    <a class="btn btn-info" href="concert.php" role="button"> <- Ticket Page</a>
                </p>
            </div>
        </div>
    </div>

    <!-- Sciprt Import for css and bootsrtraps -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
</body>
</html>