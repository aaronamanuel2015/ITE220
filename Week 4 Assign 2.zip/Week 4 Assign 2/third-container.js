// mouse over
function over() {
	document.getElementById('mouse').innerHTML = "On Mouse Over";
}

// mouse out
function out() {
	document.getElementById('mouse').innerHTML= "On Mouse Out";
}

// mouse down
function down(){
	document.getElementById("mouse").innerHTML = "On Mouse Down"
}

//mouse up
function up(){
	document.getElementById("mouse").innerHTML = "On Mouse Up"
}

//double click
function double() {
	document.getElementById("mouse").innerHTML = "On Double Click"
}