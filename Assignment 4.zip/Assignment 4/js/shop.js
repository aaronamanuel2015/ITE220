var customername= "Aron";
var products =["Pizza","Naan","Sourdough","Foccacia","iPhone X"];
var price = [40,10,20,80,1000];
var quantity =[1,1,1,1,1];
var promotion = .25;
var greeting = "";
var time = new Date().getHours();
if (time < 12) {
greeting = "Good morning";
} else if (time < 18) {
greeting = "Good afternoon";
} else {
greeting = "Good evening";
}
document.getElementById('greeting').innerHTML=greeting;

var i;
var totalprice=0;
var productsText="";
var productsElement = document.getElementById('product-list');
for(i = 0;i<products.length;i++){

	productsText = productsText + "<li class='list-group-item'>" + products[i] + "<span class='badge badge-light float-right'>$" + price [i] + "</li>";;
	productsElement.innerHTML = productsText;
	totalprice = price[i] * quantity[i];
}


document.getElementById("customer-name").innerHTML=customername;
document.getElementById("price").innerHTML="$"+totalprice*(1-promotion) + "<span class='badge badge-light float-right'>25% off";
document.getElementById("greeting").innerHTML=greeting;