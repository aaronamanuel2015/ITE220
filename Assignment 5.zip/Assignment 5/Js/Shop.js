var greeting;
var time = new Date().getHours();
if (time<12){
	greeting = "Good morning";
} else if (time<18){
	greeting = "Good afternoon";
} else {
	greeting = "Good evening";
}

var customerName = "Random";
var products = ["Pizza","Plane bun","Whole wheat bun","Burger bun"];
var price = [300, 20, 30, 25];
var quantity = [1, 2, 1, 4];
var i;
var totalPrice =0;
var promotion = .25;
var productsText ="";
var productsElement = document.getElementById("products");
for (i = 0; i < products.length; i++) {
	productsText = productsText + "<li class='list-group-item'>" + products[i] + "<span class='badge badge-pill badge-secondary float-right'>฿" + price [i] + "</li>";
	productsElement.innerHTML = productsText;
	totalPrice += price[i] * quantity[i];

}

var displayTotalPrice = totalPrice * (1-promotion);
displayTotalPrice = displayTotalPrice.toFixed(2);

document.getElementById("customername").innerHTML = customerName;
document.getElementById("price").innerHTML = "฿" + displayTotalPrice + "<span class='badge badge-pill badge-danger'>25% off"; 
document.getElementById("greeting").innerHTML = greeting;
